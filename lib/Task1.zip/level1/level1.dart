import 'dart:io';

import 'package:untitled/even_odd.dart';

// question 1 finding age of people (a)
/*void main(){
  print("Enter your name: ");
  String name=stdin.readLineSync()!;
  print("Enter your age: ");
  int age=int.parse(stdin.readLineSync()!);
  int remainAge=100-age;
  print("hello $name. your $remainAge away from 100 years");
}*/



// question 3 of maths
/*void main(){
  print("Enter any principle: ");
  int principle=getValue();
  print("Enter any rate: ");
  int rate=getValue();
  print("Enter any time: ");
  int time=getValue();
 num Si=principle*rate*time/100;
 print(Si);
}
int getValue()=> int.parse(stdin.readLineSync()!);
*/


// for square for any no
/*void main(){
  print("Enter any no for square:");
  int no=getValue();
  int square=no*no;
  print("$square of the given no");
}
 */


// calculate the time to reach the office
/*void main(){
print("Enter your distance btw home and office in meter: ");
int d=getValue();
print("Enter your speed in m/s: ");
int s=getValue();
double tm = d/s;
double time=tm/60;
print("$time min.");
}*/


// splitting bills
/*void main(){
  print("Enter no of persons want to share bills: ");
  int persons=getValue();
  print("Enter the amount of bill: ");
  int amount=getValue();
  double splits=amount /persons;
  print(" you have $splits");
}*/

// checking of a odd or even no
/*void main(){
  print("Enter any no for checking: ");
  int n1=getValue();
  if(n1%2==0){
    print("this is a even no");
  }
  else{
      print("this is a odd no");
    };
  }*/


//multiplications tables of given no
/*void main(){
  print("Enter any no for table: ");
  int n=getValue();
  int multi=0;
  for(int i=1; i<=10;i++){
    multi=n*i;
    print( multi);
  }
}*/




//conditional programming
/*void main(){
  print("Enter any alphabet:");
  String alp=stdin.readLineSync()!;
  if(alp=="a" ||alp=="e" ||alp=="i" ||alp=="o" ||alp=="u" ||alp=="A" ||alp=="E" ||alp=="I" ||alp=="O" ||alp=="U" ){
    print("this is a vowel");
  }
  else{
    print("this is a consonant");
  };
}*/



// no is -ve and +ve
/*void main(){
  print("Enter any no to check:");
  int no=getValue();
  if(no>0){
  print("this is a positive no");
  }
  else if(no<0){
    print("this is a negative");
  }
  else{
    print("this is zero");
    };
}*/



// oops in dart
/*void main () {
  //extends
Cat n= Cat();
n.breath("cat is taking 02");
n.sleep("cat is sleeping");
n.sound("cat is meowing");
n.eat("cat food");
n.drink("cat is taking water");
// implement
Home house=Home();
house.place("living in house" );
house.eat("a place where animal eat");
house.sleep("where we sleep");
house.place("where we put all electronic like Laptop,Camera");
house.ram("contain products having RAM");
}
class Laptop {
  void palce(String){
    print(String);
  }
  void ram(String) {
    print(String);
  }
  void mod(String) {
    print(String);
  }
}


  class House{
  void contain(){
    print("containing of products");
  }

  }


  class Animal{
    void place(String){
      print(String);
    }
  void eat(String){
    print(String);
  }
  void sound(String){
    print(String);
  }
  void sleep(String){
    print(String);
  }
  void drink(String){
    print(String);
  }
  void breath(String){
    print(String);
  }
  void play(String){
    print(String);
  }
  }
  class Camera{
  void click(String){
    print(String);
  }
  void pixel(String){
    print(String);
  }
  void mod() {
    print("13th gen");
  }
  }
  class Cat extends Animal{
  }
  class Home implements Laptop,Animal {
  @override
   void place(home){
    print("this is home");
  }

@override
void eat(food) {
  print("contain yummy foods");
}
@override
void drink(water) {
  print("contain tasteless water");
}
@override
void ram( ram){
    print("house contain these type of products");
  }
@override
void sleep(sleeping){
    print("everyone sleep or rest in there house");
}
@override
    void mod(modle){
    print("different type of modules");
}
@override
   void breath( o2){
    print("breathing is for living organisms ");
}
@override
    void play(playing){
    print("in house we do indoor actives works");
}
@override
    void palce(house){
    print("in house");
}
@override
void sound(sound){
    print("create a unique sound");
}
}
 */



//                                                    collection question
// for  maps and update
/*void main(){
  print("Enter your review for teacher: ");
  String n1=stdin.readLineSync()!;
  Map<String,String> main={
    "Name":"Nikita",
    "class":"12th",
    "rollNo": "15",
    "mobileNo":"xxxxxxx578",
    "subjects": "5",
    "review":n1,
  };
  print(main);
}*/

// list and sets
/*void main() {
  List<String> list = ["nikita", "kalpana", "sukrti", "renku", "nisha"];
  print(list.first);
  print(list.reversed);
  print(list.isEmpty);
  print(list.last);
  }
 */

// for set
 /*void main(){

  Set<String> no={"monday","tuesday","wednesday","wednesday","saturday"};
  print(no);
}*/

// working with day and expenses
/*void main(){
  print("Enter any other day  if u have: ");
  String s1=stdin.readLineSync()!;
  print("Enter amount of the expense:");
  int n1=getValue();
  Map<String,int> expenses={
    "monday":2000,
    "tuesday":500,
    "wednesday":3000,
    "thursday":2000,
    "friday":1000,
    "saturday":1500,
    s1:n1,
  };
  print (expenses);
}
 */



// filtering list elements with conditions
/*void main(){
  print("Enter numbers for filtration elements: ");
  int n1=getValue();
  int n2=getValue();
  int n3=getValue();
  int n4=getValue();
  List<int> elements=[n1,n2,n3,n4];
    if (n1%2==0&&n2%2==0&&n3%2==0&&n4%2==0){
    print("$elements is even list");
  }
  else{
    print("there is no list formed from these nos");
  }
}*/




//                                                                   function questions


// print name n time name for a function declaration
/*void main(){
  print("Enter name you want to print in function: ");
  String name=consoleValue();
  print("Enter how many time you print: ");
  int no=getValue();
   for(int i=1;i<=no;i++){
    print(name);
   }
}
void  name(name) {
    print(name);
}*/



// greet function for greeting
/*void main(){
  print("Enter you name for greeting: ");
  String s1=stdin.readLineSync()!;
  greet("$s1");
}
void greet(s1){
  print("hi,$s1. nice to meet to you");
}*/



// for mathematical function
/*void main(){
 print( mathsOper(5, 6));
}
int mathsOper(int n1,int n2 ){
  return n1*n2;
}*/


//printing even no btw an interval
/*void main(){
  print("Enter no from where  interval start: ");
  int n1=getValue();
  print("Enter last no of interval: ");
  int n2=getValue();
  even(n1, n2);
}
num even(int n1,int n2){
  for (int i=n1;i<=n2;i++){
    if(i%2==0){
      print(i);
    }
  }
return n1;
}
 */



// nullable to hand int parameter

/*void main(){
  print("Enter any value for multiply: ");
  int n1=getValue();
  print("Enter any second value for multiply: ");
  int? n2=int.tryParse(stdin.readLineSync()?? "");
 print (handler(n1,n2));
}
int handler(int n1,int? n2){
  return n1*(n2??1) +1;
}

 */



// simple calculator
/*void main(){
  print("Enter any 1st no for operation: ");
  int n1=getValue();
  print("Enter any 2nd no for operation: ");
  int n2=getValue();
  print("Enter operation you want to perform btw two no: ");
  String n3=stdin.readLineSync()!;
  if(n3=="add" || n3=="Add" || n3=="Addition" || n3=="addition"){
    print(n1*n2);
  }
   else  if (n3=="subtract" || n3=="subtract" || n3=="sub" || n3=="Sub"){
    print(n1-n2);
  }
   else if (n3=="divide" || n3=="Divide" || n3=="div"){
    print(n1/n2);
  }
  else(n3=="multiply" || n3=="multiplication" || n3=="Multiply" ||n3=="Multiplication");{
    print(n1*n2);
  };
}
 */

// 2 power of a no
/*void main(){
  print("Enter any for the power: ");
  int no=getValue();
  int  power=no*no;
  print(power);
}
 */


//                    string
// for single and double qu.
/*void main(){
print("hi, how are you u fine");
print('i hope u are fine');
}
 */



// print name
/*void main(){
  print("Enter any string value: ");
  String name=stdin.readLineSync()!;
  print("my name is $name");
}
 */



// convert string to
 /*     void main(){
        String? name=" three";
   int  no=int.tryParse(name)! ;
   int finale=int.tryParse(name)??0;
    print(name);
}*/

//reversing a string using a function
/*void main() {
  print("Enter any string value: ");
  String n1 = stdin.readLineSync()!;
  String n2= stdin.readLineSync()!;
  print(reverse(n1, n2));
}
String reverse(n1,n2) {
  return n2 + n1;
}
 */





// purpose of ?
//we use this where we know that it can be null then we give them default value when use don't do that.

/*there are three types by which we handle nullable
1.bool
2.!
3.??*/



/*void main(){
  print("Enter any no: ");
  int? no;
  print(no);
  print("Enter any other value: ");
  int n1=int.parse(stdin.readLineSync()!);
  // here! this told us we are going to provide you value absolutely
  print(n1);

}
//it told us that it is null
*/


// handling null by ??
/*void main(){
  print("Enter any 1 no:");
  int n1=getValue();
  print("Enter any 2 no: ");
  int n2=int.tryParse(stdin.readLineSync()??"")??1;
  int multi=(n1??1)*n2;
  print(multi);

}
 */


//Buzz Fuzz
/*void main() {
  print("lets start");
  for (int i = 1; i <= 100;i++){
    if(i%2==0){
      print("Fizz");
    }
    else if(i%4==0){
      print("Buzz");
    }
    else if(i %3==0){
      print("Buzz-Fuzz");
    }
    else {
      print(i);
    }
  }
}*/




//// lets play rock-paper-scissor
// /*void main(){
//   print("Enter your choose player1:");
//   String player1=stdin.readLineSync()!;
//   print("Enter your choose player2:");
//   String player2=stdin.readLineSync()!;
// List<String> RockPaper=["Rock","Paper","Scissor"];
// RockPaper.shuffle();
// print(RockPaper[1]);
// }*/


//hangmen game
/*void main() {
print(" use  only following character e,p,k,b,o,m");
print("_,_,_,b,_,_");
print("Enter 1st character for the guess: ");
String s1 = consoleValue();
if (s1 == "p") {
print("WOW, p,_,_,b,_,_");
}
else{
print("hehe , pig");}

print("Enter 2nd char:");
String s2 = consoleValue();
if (s2 == "e") {
print("WOW, p,e,_,b,_,_");
}
else{
print("hehe , pig");}

print("Enter 3rd char: ");
String s3 = consoleValue();
if (s3 == "k") {
print("WOW,p,e,k,b,_,_");
}
else{
print("hehe , pig");}

print("Enter 4rd char: ");
String s4 = consoleValue();
if (s4 == "o") {
print("WOW,p,e,k,b,o,_");
}
else{
print("hehe , pig");}

print("Enter 5rd char: ");
String s5 = consoleValue();

if (s5 == "m") {
print("it is p,e,k,b,o,m");

}
else{
print("hehe,you lose pig");}
}

String consoleValue(){
return stdin.readLineSync()!;
}*/




//to do app
/*void main(){
  print("task 1 \n brush your teeth \n tell me yes or no");
  String s1=consoleValue();
  if(s1=="yes"){
    print("Well done.");
  }
  else {
    print("go do it man, you can do it");
  }
    print("task2 \n go for running\n tell me yes or no");
    String s2=consoleValue();
    if(s2=="yes") {
      print("Well done");
    }
      else{
        print("kr le bhai");
    }
    print("task3 \n take shower\n tell me yes or no");
    String s3=consoleValue();
    if(s3=="yes"){
      print("Well done ");
  }
    else{
      print("go do your work lazy person");
    }
  print("Want to add another task");
    String s4=consoleValue();
}
 */



// que. and remainder of two integers
/*void main(){
  print("Enter you no by which you want to divide: ");
  int n1=2;
  print("Enter whom you want to divide: ");
  int n2=33;
  int quotient=n2~/n1;
  int remainder=n2%n1;
  print(remainder);
  print(quotient);
}

 */


//


















